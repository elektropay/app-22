import React from 'react'
import { Select, Tag, Tabs, Dropdown, Menu, Alert, Spin, Table, Radio, Form, Input } from 'antd'
import { Helmet } from 'react-helmet'
import { Scrollbars } from 'react-custom-scrollbars'
import Sticky from 'react-stickynode'
import TradeChart from './TradeChart'
import getData from './TradeChart/utils'
import styles from './style.module.scss'
import { myOpenOrdersData, marketHistoryData, orderBookBuy, orderBookSell } from './data.json'

const { TabPane } = Tabs

const dropdownMenu = (
  <Menu>
    <Menu.Item>
      <a href="#" onClick={e => e.preventDefault()}>
        Action
      </a>
    </Menu.Item>
    <Menu.Item>
      <a href="#" onClick={e => e.preventDefault()}>
        Another action
      </a>
    </Menu.Item>
    <Menu.Item>
      <a href="#" onClick={e => e.preventDefault()}>
        Something else here
      </a>
    </Menu.Item>
    <div className="dropdown-divider" />
    <Menu.Item>
      <a href="#" onClick={e => e.preventDefault()}>
        Separated link
      </a>
    </Menu.Item>
  </Menu>
)

class DashboardCryptoTerminal extends React.Component {
  state = {
    orderType: 'buy',
    graphData: null,
    myOpenOrders: {
      loading: false,
      loaded: false,
      data: myOpenOrdersData,
    },
    myOrderHistory: {
      loading: false,
      loaded: false,
      data: myOpenOrdersData,
    },
    marketHistory: {
      data: marketHistoryData,
    },
    orderBook: {
      buy: orderBookBuy,
      sell: orderBookSell,
    },
  }

  componentDidMount() {
    getData().then(data => {
      this.setState({ graphData: data })
    })
  }

  handleMyOpenOrders = e => {
    e.preventDefault()
    const { myOpenOrders } = this.state
    this.setState({
      myOpenOrders: {
        ...myOpenOrders,
        loading: true,
      },
    })
    setTimeout(() => {
      this.setState({
        myOpenOrders: {
          ...myOpenOrders,
          loading: false,
          loaded: true,
        },
      })
    }, 1500)
  }

  handleMyOrderHistory = e => {
    e.preventDefault()
    const { myOrderHistory } = this.state

    this.setState({
      myOrderHistory: {
        ...myOrderHistory,
        loading: true,
      },
    })
    setTimeout(() => {
      this.setState({
        myOrderHistory: {
          ...myOrderHistory,
          loading: false,
          loaded: true,
        },
      })
    }, 1500)
  }

  toggleOrderType = e => {
    this.setState({
      orderType: e.target.value,
    })
  }

  render() {
    const {
      graphData,
      myOpenOrders,
      myOrderHistory,
      marketHistory,
      orderBook,
      orderType,
    } = this.state

    const myOrderColumns = [
      {
        title: 'Order Date',
        dataIndex: 'orderDate',
        key: 'orderDate',
      },
      {
        title: 'Open Date',
        dataIndex: 'openDate',
        key: 'openDate',
      },
      {
        title: 'Type',
        dataIndex: 'type',
        key: 'type',
        render: value => (
          <span style={{ color: value === 'SELL' ? '#f75535' : '#00a45b' }}>{value}</span>
        ),
      },
      {
        title: 'Bid/Ask',
        dataIndex: 'bidAsk',
        key: 'bidAsk',
      },
      {
        title: 'Filled',
        dataIndex: 'filled',
        key: 'filled',
      },
      {
        title: 'Units Total',
        dataIndex: 'unitsTotal',
        key: 'unitsTotal',
      },
      {
        title: 'Actual Rate',
        dataIndex: 'actualRate',
        key: 'actualRate',
      },
      {
        title: 'Est. Total',
        dataIndex: 'estTotal',
        key: 'estTotal',
      },
    ]

    const marketHistoryColumns = [
      {
        title: 'Date',
        dataIndex: 'orderDate',
        key: 'orderDate',
      },
      {
        title: 'BUY/SELL',
        dataIndex: 'type',
        key: 'type',
        render: value => (
          <span style={{ color: value === 'SELL' ? '#f75535' : '#00a45b' }}>{value}</span>
        ),
      },
      {
        title: 'Bid/Ask',
        dataIndex: 'bidAsk',
        key: 'bidAsk',
      },
      {
        title: 'Units Total',
        dataIndex: 'unitsTotal',
        key: 'unitsTotal',
      },
      {
        title: 'Total Cost',
        dataIndex: 'totalCost',
        key: 'totalCost',
      },
    ]

    const ordersSellColumns = [
      {
        title: 'SUM',
        dataIndex: 'sum',
        key: 'sum',
        align: 'right',
      },
      {
        title: 'Total',
        dataIndex: 'total',
        key: 'total',
        align: 'right',
      },
      {
        title: 'Size',
        dataIndex: 'size',
        key: 'size',
        align: 'right',
      },
      {
        title: 'BID',
        dataIndex: 'bid',
        key: 'bid',
        width: 120,
        align: 'right',
        render: value => {
          return <span style={{ color: '#00a45b' }}>{value}</span>
        },
      },
      {
        title: '',
        dataIndex: 'sell',
        key: 'sell',
        width: 60,
        align: 'right',
        render: () => {
          return (
            <a href="#" onClick={e => e.preventDefault()} className="utils__link--blue mr-2">
              <strong>SELL</strong>
            </a>
          )
        },
      },
    ]

    const ordersBuyColumns = [
      {
        title: '',
        dataIndex: 'sell',
        key: 'sell',
        width: 60,
        render: () => {
          return (
            <a href="#" onClick={e => e.preventDefault()} className="utils__link--blue ml-2">
              <strong>BUY</strong>
            </a>
          )
        },
      },
      {
        title: 'ASK',
        dataIndex: 'ask',
        key: 'ask',
        width: 120,
        render: value => {
          return <span style={{ color: '#f75535' }}>{value}</span>
        },
      },
      {
        title: 'Size',
        dataIndex: 'size',
        key: 'size',
      },
      {
        title: 'Total',
        dataIndex: 'total',
        key: 'total',
      },
      {
        title: 'SUM',
        dataIndex: 'sum',
        key: 'sum',
      },
    ]

    return (
      <div>
        <Helmet title="Crypto Terminal" />
        <div className={styles.cryptoTerminal}>
          <Select
            showSearch
            size="large"
            defaultValue="btc"
            style={{ width: '100%' }}
            className="d-lg-none mb-3"
          >
            <Select.Option value="btc">
              BTC (Bitcoin)
              <Tag color="blue" className="ml-3">
                11.7%
              </Tag>
            </Select.Option>
            <Select.Option value="xmr">
              XMR (Monero)
              <Tag color="blue" className="ml-3">
                67.5%
              </Tag>
            </Select.Option>
            <Select.Option value="gld">
              GLD (GoldCoin)
              <Tag color="red" className="ml-3">
                -22.9%
              </Tag>
            </Select.Option>
            <Select.Option value="neo">
              NEO (Neo)
              <Tag color="red" className="ml-3">
                -12.3%
              </Tag>
            </Select.Option>
            <Select.Option value="btg">
              BTG (Bitcoin Gold)
              <Tag color="blue" className="ml-3">
                +4.3%
              </Tag>
            </Select.Option>
            <Select.Option value="xrp">
              XRP (Ripple)
              <Tag color="red" className="ml-3">
                -4.2%
              </Tag>
            </Select.Option>
            <Select.Option value="zec">
              ZEC (ZCash)
              <Tag color="red" className="ml-3">
                -1.7%
              </Tag>
            </Select.Option>
            <Select.Option value="neo">
              ZCL (ZClassic)
              <Tag color="red" className="ml-3">
                -2.8%
              </Tag>
            </Select.Option>
          </Select>
          <div className={styles.listContainer} id="scroll-container">
            <Sticky top={30} bottomBoundary="#scroll-container">
              <div className={styles.list}>
                <div className="bg-gray-1 rounded h-100">
                  <Scrollbars
                    renderThumbVertical={({ style, ...props }) => (
                      <div
                        {...props}
                        style={{
                          ...style,
                          width: '4px',
                          borderRadius: 'inherit',
                          backgroundColor: '#c5cdd2',
                          left: '1px',
                        }}
                      />
                    )}
                    autoHide
                  >
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">RVN</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        5.2% <span>↑</span>
                      </div>
                    </a>
                    <a
                      href="#"
                      onClick={e => e.preventDefault()}
                      className={`${styles.item} p-1 bg-gray-3`}
                    >
                      <div className="font-size-16 text-uppercase">BTC</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        1.4% <span>↑</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">XRP</div>
                      <div className="text-danger font-size-14 align-text-bottom">
                        5.2% <span>↓</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">ADA</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        6.8% <span>↑</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">BSV</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        8.9% <span>↑</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">TUSD</div>
                      <div className="text-danger font-size-14 align-text-bottom">
                        5.2% <span>↓</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">MTL</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        8.9% <span>↑</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">RVN</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        5.2% <span>↑</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">BTC</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        1.4% <span>↑</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">XRP</div>
                      <div className="text-danger font-size-14 align-text-bottom">
                        5.2% <span>↓</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">ADA</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        6.8% <span>↑</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">BSV</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        8.9% <span>↑</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">TUSD</div>
                      <div className="text-danger font-size-14 align-text-bottom">
                        5.2% <span>↓</span>
                      </div>
                    </a>
                    <a href="#" onClick={e => e.preventDefault()} className={`${styles.item} p-1`}>
                      <div className="font-size-16 text-uppercase">MTL</div>
                      <div className="text-success font-size-14 align-text-bottom">
                        8.9% <span>↑</span>
                      </div>
                    </a>
                  </Scrollbars>
                </div>
              </div>
            </Sticky>
          </div>
          <div className={styles.content}>
            <div className="card">
              <div className="card-header card-header-flex">
                <Tabs defaultActiveKey="1" className="air-tabs-bold mr-auto">
                  <TabPane tab="MARKET CHART" key="1" />
                  <TabPane tab="DEPTH CHART" key="2" />
                </Tabs>
                <div className="d-inline-flex align-items-center">
                  <Dropdown overlay={dropdownMenu} placement="bottomRight">
                    <a
                      className="nav-link dropdown-toggle"
                      href="#"
                      onClick={e => e.preventDefault()}
                      role="button"
                    >
                      30m
                    </a>
                  </Dropdown>
                </div>
                <div className="d-inline-flex align-items-center">
                  <Dropdown overlay={dropdownMenu} placement="bottomRight">
                    <a
                      className="nav-link dropdown-toggle"
                      href="#"
                      onClick={e => e.preventDefault()}
                      role="button"
                    >
                      Views
                    </a>
                  </Dropdown>
                </div>
              </div>
              <div className="card-body">
                <div style={{ height: 400 }}>
                  {graphData !== null && <TradeChart type="hybrid" data={graphData} />}
                </div>
              </div>
            </div>
            <div className="card">
              <div className="card-body">
                <h5 className="mb-3">Order Book</h5>
                <div className="d-block d-xl-flex">
                  <div className="flex-grow-1">
                    <div className={`${styles.table} text-nowrap`}>
                      <Table
                        className="air__utils__scrollTable"
                        scroll={{ x: '100%' }}
                        columns={ordersSellColumns}
                        dataSource={orderBook.sell}
                        pagination={{ position: 'bottom' }}
                        size="small"
                      />
                    </div>
                  </div>
                  <div className="width-250 mx-auto mx-xl-4">
                    <Form layout="vertical">
                      <Form.Item>
                        <Radio.Group
                          onChange={this.toggleOrderType}
                          value={orderType}
                          style={{ width: '100%' }}
                        >
                          <Radio.Button value="buy" style={{ width: '50%', textAlign: 'center' }}>
                            BUY
                          </Radio.Button>
                          <Radio.Button value="sell" style={{ width: '50%', textAlign: 'center' }}>
                            SELL
                          </Radio.Button>
                        </Radio.Group>
                      </Form.Item>
                      {orderType === 'buy' && (
                        <div>
                          <span className="crypto__formLabel">ORDER TYPE</span>
                          <Form.Item>
                            <Select defaultValue="limit">
                              <Select.Option value="limit">Limit (Default)</Select.Option>
                              <Select.Option value="conditional">Conditional</Select.Option>
                            </Select>
                          </Form.Item>
                          <span className="crypto__formLabel">QUANTITY (BTC)</span>
                          <Form.Item>
                            <Input value="0.00000000" />
                          </Form.Item>
                          <span className="crypto__formLabel">BID PRICE</span>
                          <Form.Item>
                            <Input value="0.00645198" />
                          </Form.Item>
                          <span className="crypto__formLabel">TOTAL</span>
                          <Form.Item>
                            <Input value="0.00000000" />
                          </Form.Item>
                          <span className="crypto__formLabel">TIME IN FORCE</span>
                          <Form.Item>
                            <Select defaultValue="good">
                              <Select.Option value="good">
                                Good Til Cancelled (Default)
                              </Select.Option>
                              <Select.Option value="immediate">Immediate or Cancel</Select.Option>
                            </Select>
                          </Form.Item>
                          <div className="btn btn-success" style={{ width: '100%' }}>
                            <strong>BUY BTC</strong>
                          </div>
                          <div className="my-3 text-center">
                            <div>
                              <strong>Available Balance</strong>
                            </div>
                            <div>12.92520000 BTC</div>
                            <div>1450.00 USD</div>
                            <div>
                              <a
                                href="#"
                                onClick={e => e.preventDefault()}
                                className="utils__link--blue utils__link--underlined"
                              >
                                <strong>Max Buy</strong>
                              </a>
                            </div>
                          </div>
                        </div>
                      )}
                      {orderType === 'sell' && (
                        <div>
                          <span className="crypto__formLabel">ORDER TYPE</span>
                          <Form.Item>
                            <Select defaultValue="limit">
                              <Select.Option value="limit">Limit (Default)</Select.Option>
                              <Select.Option value="conditional">Conditional</Select.Option>
                            </Select>
                          </Form.Item>
                          <span className="crypto__formLabel">QUANTITY (BTC)</span>
                          <Form.Item>
                            <Input value="0.00000000" />
                          </Form.Item>
                          <span className="crypto__formLabel">ASK PRICE</span>
                          <Form.Item>
                            <Input value="0.00645198" />
                          </Form.Item>
                          <span className="crypto__formLabel">TOTAL</span>
                          <Form.Item>
                            <Input value="0.00000000" />
                          </Form.Item>
                          <span className="crypto__formLabel">TIME IN FORCE</span>
                          <Form.Item>
                            <Select defaultValue="good">
                              <Select.Option value="good">
                                Good Til Cancelled (Default)
                              </Select.Option>
                              <Select.Option value="immediate">Immediate or Cancel</Select.Option>
                            </Select>
                          </Form.Item>
                          <div className="btn btn-danger" style={{ width: '100%' }}>
                            <strong>SELL BTC</strong>
                          </div>
                          <div className="my-3 text-center">
                            <div>
                              <strong>Available Balance</strong>
                            </div>
                            <div>12.92520000 BTC</div>
                            <div>1450.00 USD</div>
                            <div>
                              <a
                                href="#"
                                onClick={e => e.preventDefault()}
                                className="utils__link--blue utils__link--underlined"
                              >
                                <strong>Max SELL</strong>
                              </a>
                            </div>
                          </div>
                        </div>
                      )}
                    </Form>
                  </div>
                  <div className="flex-grow-1">
                    <div className={`${styles.table} text-nowrap`}>
                      <Table
                        className="air__utils__scrollTable"
                        scroll={{ x: '100%' }}
                        columns={ordersBuyColumns}
                        dataSource={orderBook.buy}
                        pagination={{ position: 'bottom' }}
                        size="small"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="card">
              <div className="card-body">
                <h5 className="mb-3">Market History</h5>
                <div className={`${styles.table} text-nowrap`}>
                  <Table
                    className="air__utils__scrollTable"
                    scroll={{ x: '100%' }}
                    columns={marketHistoryColumns}
                    dataSource={marketHistory.data}
                    pagination={{ position: 'bottom' }}
                    size="small"
                  />
                </div>
              </div>
            </div>
            <div className="card">
              <div className="card-body">
                <h5 className="mb-3">My Open Orders</h5>
                <div>
                  {!myOpenOrders.loaded && (
                    <a href="#" onClick={this.handleMyOpenOrders}>
                      <Spin spinning={myOpenOrders.loading}>
                        <Alert
                          className={styles.warning}
                          message="Click to view open order details"
                          type="info"
                        />
                      </Spin>
                    </a>
                  )}
                  {myOpenOrders.loaded && (
                    <div className={`${styles.table} text-nowrap`}>
                      <Table
                        className="air__utils__scrollTable"
                        scroll={{ x: '100%' }}
                        columns={myOrderColumns}
                        dataSource={myOpenOrders.data}
                        pagination={{ position: 'bottom' }}
                        size="small"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="card">
              <div className="card-body">
                <h5 className="mb-3">My Order History</h5>
                <div>
                  {!myOrderHistory.loaded && (
                    <a href="#" onClick={this.handleMyOrderHistory}>
                      <Spin spinning={myOrderHistory.loading}>
                        <Alert
                          className={styles.warning}
                          message="Click to view open order details"
                          type="info"
                        />
                      </Spin>
                    </a>
                  )}
                  {myOrderHistory.loaded && (
                    <div className={`${styles.table} text-nowrap`}>
                      <Table
                        className="air__utils__scrollTable"
                        scroll={{ x: '100%' }}
                        columns={myOrderColumns}
                        dataSource={myOpenOrders.data}
                        pagination={{ position: 'bottom' }}
                        size="small"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default DashboardCryptoTerminal
