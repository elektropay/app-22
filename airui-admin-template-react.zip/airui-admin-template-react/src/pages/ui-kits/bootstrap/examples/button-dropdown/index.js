import React from 'react'
import { ButtonDropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap'

class BootstrapButtonDropdownExample extends React.Component {
  constructor(props) {
    super(props)

    this.toggle = this.toggle.bind(this)
    this.state = {
      dropdownOpen: false,
    }
  }

  toggle() {
    const { dropdownOpen } = this.state

    this.setState({
      dropdownOpen: !dropdownOpen,
    })
  }

  render() {
    const { dropdownOpen } = this.state

    return (
      <div className="height-200">
        <ButtonDropdown isOpen={dropdownOpen} toggle={this.toggle}>
          <DropdownToggle caret>Button Dropdown</DropdownToggle>
          <DropdownMenu>
            <DropdownItem header>Header</DropdownItem>
            <DropdownItem disabled>Action</DropdownItem>
            <DropdownItem>Another Action</DropdownItem>
            <DropdownItem divider />
            <DropdownItem>Another Action</DropdownItem>
          </DropdownMenu>
        </ButtonDropdown>
      </div>
    )
  }
}

export default BootstrapButtonDropdownExample
