import React from 'react'
import { Tooltip } from 'reactstrap'

class BootstrapTooltipsExample extends React.Component {
  constructor(props) {
    super(props)

    this.toggle = this.toggle.bind(this)
    this.state = {
      tooltipOpen: false,
    }
  }

  toggle() {
    const { tooltipOpen } = this.state

    this.setState({
      tooltipOpen: !tooltipOpen,
    })
  }

  render() {
    const { tooltipOpen } = this.state

    return (
      <div>
        <div>
          <p>
            Somewhere in here is a{' '}
            <span
              style={{ textDecoration: 'underline', color: 'blue' }}
              href="#"
              id="TooltipExample"
            >
              tooltip
            </span>
            .
          </p>
          <Tooltip
            placement="right"
            isOpen={tooltipOpen}
            target="TooltipExample"
            toggle={this.toggle}
          >
            Hello world!
          </Tooltip>
        </div>
      </div>
    )
  }
}

export default BootstrapTooltipsExample
