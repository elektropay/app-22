/* eslint-disable */
import React from 'react'
import { Alert } from 'antd'

class AntdAlertExample extends React.Component {
  render() {
    return (
      <div>
        <Alert message="Success Text" type="success" />
      </div>
    )
  }
}

export default AntdAlertExample
