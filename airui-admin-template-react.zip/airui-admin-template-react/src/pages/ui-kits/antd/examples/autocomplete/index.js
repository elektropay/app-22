/* eslint-disable */
import React from 'react'
import { AutoComplete } from 'antd'

function onSelect(value) {
  console.log('onSelect', value)
}

class AntdAutoCompleteExample extends React.Component {
  state = {
    value: '',
    dataSource: [],
  }

  onSearch = searchText => {
    this.setState({
      dataSource: !searchText ? [] : [searchText, searchText.repeat(2), searchText.repeat(3)],
    })
  }

  onChange = value => {
    this.setState({ value })
  }

  render() {
    return (
      <div>
        <AutoComplete
          dataSource={this.state.dataSource}
          style={{ width: 200 }}
          onSelect={onSelect}
          onSearch={this.onSearch}
          placeholder="input here"
        />
        <br />
        <br />
        <AutoComplete
          value={this.state.value}
          dataSource={this.state.dataSource}
          style={{ width: 200 }}
          onSelect={onSelect}
          onSearch={this.onSearch}
          onChange={this.onChange}
          placeholder="control mode"
        />
      </div>
    )
  }
}

export default AntdAutoCompleteExample
