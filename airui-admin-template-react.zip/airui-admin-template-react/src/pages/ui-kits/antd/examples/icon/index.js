/* eslint-disable */
import React from 'react'
import { Icon } from 'antd'

class AntdIconExample extends React.Component {
  render() {
    return (
      <div className="icons-list">
        <Icon type="home" />
        <Icon type="setting" theme="filled" />
        <Icon type="smile" theme="outlined" />
        <Icon type="sync" spin />
        <Icon type="smile" rotate={180} />
        <Icon type="loading" />
        <style>{`.icons-list > .anticon {
  margin-right: 6px;
  font-size: 24px;
}`}</style>
      </div>
    )
  }
}

export default AntdIconExample
