/* eslint-disable */
import React from 'react'
import { Badge, Icon } from 'antd'

class AntdBadgeExample extends React.Component {
  render() {
    return (
      <div>
        <Badge count={5}>
          <a href="#" className="head-example" />
        </Badge>
        <Badge count={0} showZero>
          <a href="#" className="head-example" />
        </Badge>
        <Badge count={<Icon type="clock-circle" style={{ color: '#f5222d' }} />}>
          <a href="#" className="head-example" />
        </Badge>
        <style>{`
          .ant-badge:not(.ant-badge-not-a-wrapper) {
            margin-right: 20px;
          }
          .head-example {
            width: 42px;
            height: 42px;
            border-radius: 4px;
            background: #eee;
            display: inline-block;
            vertical-align: middle;
          }
        `}</style>
      </div>
    )
  }
}

export default AntdBadgeExample
