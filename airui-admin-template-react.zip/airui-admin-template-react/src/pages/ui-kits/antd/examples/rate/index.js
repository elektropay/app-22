/* eslint-disable */
import React from 'react'
import { Rate } from 'antd'

class AntdRateExample extends React.Component {
  render() {
    return (
      <div>
        <Rate />
      </div>
    )
  }
}

export default AntdRateExample
