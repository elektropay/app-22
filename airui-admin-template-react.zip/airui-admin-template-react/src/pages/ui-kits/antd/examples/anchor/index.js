/* eslint-disable */
import React from 'react'
import { Anchor } from 'antd'

const { Link } = Anchor

class AntdAnchorExample extends React.Component {
  render() {
    return (
      <div>
        <Anchor>
          <Link href="#" title="Basic demo" />
          <Link href="#" title="Static demo" />
          <Link href="#" title="Basic demo with Target" />
          <Link href="#" title="API">
            <Link href="#" title="Anchor Props" />
            <Link href="#" title="Link Props" />
          </Link>
        </Anchor>
      </div>
    )
  }
}

export default AntdAnchorExample
