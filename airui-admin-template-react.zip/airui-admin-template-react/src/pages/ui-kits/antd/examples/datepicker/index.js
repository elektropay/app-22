/* eslint-disable */
import React from 'react'
import { DatePicker } from 'antd'

const { MonthPicker, RangePicker, WeekPicker } = DatePicker

function onChange(date, dateString) {
  console.log(date, dateString)
}

class AntdDatePickerExample extends React.Component {
  render() {
    return (
      <div>
        <DatePicker onChange={onChange} className="mb-2" />
        <br />
        <MonthPicker onChange={onChange} className="mb-2" placeholder="Select month" />
        <br />
        <RangePicker onChange={onChange} className="mb-2" />
        <br />
        <WeekPicker onChange={onChange} className="mb-2" placeholder="Select week" />
      </div>
    )
  }
}

export default AntdDatePickerExample
