/* eslint-disable */
import React from 'react'
import { Pagination } from 'antd'

class AntdPaginationExample extends React.Component {
  render() {
    return (
      <div>
        <Pagination defaultCurrent={1} total={50} />
      </div>
    )
  }
}

export default AntdPaginationExample
