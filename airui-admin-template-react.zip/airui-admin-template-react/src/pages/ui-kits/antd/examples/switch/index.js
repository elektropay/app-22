/* eslint-disable */
import React from 'react'
import { Switch } from 'antd'

function onChange(checked) {
  console.log(`switch to ${checked}`)
}

class AntdSwitchExample extends React.Component {
  render() {
    return (
      <div>
        <Switch defaultChecked onChange={onChange} />
      </div>
    )
  }
}

export default AntdSwitchExample
