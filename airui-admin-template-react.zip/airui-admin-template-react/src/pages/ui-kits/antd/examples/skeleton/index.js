/* eslint-disable */
import React from 'react'
import { Skeleton } from 'antd'

class AntdSkeletonExample extends React.Component {
  render() {
    return (
      <div>
        <Skeleton />
      </div>
    )
  }
}

export default AntdSkeletonExample
