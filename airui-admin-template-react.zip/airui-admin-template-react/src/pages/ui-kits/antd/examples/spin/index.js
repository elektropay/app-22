/* eslint-disable */
import React from 'react'
import { Spin } from 'antd'

class AntdSpinExample extends React.Component {
  render() {
    return (
      <div>
        <Spin />
      </div>
    )
  }
}

export default AntdSpinExample
