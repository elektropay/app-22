/* eslint-disable */
import React from 'react'
import { Button } from 'antd'

class AntdButtonExample extends React.Component {
  render() {
    return (
      <div>
        <Button type="primary">Primary</Button>
        <Button>Default</Button>
        <Button type="dashed">Dashed</Button>
        <Button type="danger">Danger</Button>
        <Button type="link">Link</Button>
        <style>{`
          .ant-btn {
            margin-right: 15px;
          }
        `}</style>
      </div>
    )
  }
}

export default AntdButtonExample
