/* eslint-disable */
import React from 'react'
import { Popover, Button } from 'antd'

const content = (
  <div>
    <p>Content</p>
    <p>Content</p>
  </div>
)

class AntdPopoverExample extends React.Component {
  render() {
    return (
      <div>
        <Popover content={content} title="Title">
          <Button type="primary">Hover me</Button>
        </Popover>
        <style>{`p { margin: 0; }`}</style>
      </div>
    )
  }
}

export default AntdPopoverExample
