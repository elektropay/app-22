/* eslint-disable */
import React from 'react'
import { Input } from 'antd'

class AntdInputExample extends React.Component {
  render() {
    return <Input placeholder="Basic usage" />
  }
}

export default AntdInputExample
