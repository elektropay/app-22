import React from 'react'
import { Table, Divider, Tag } from 'antd'
import data from './data.json'

const columns = [
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    render: text => <a href="">{text}</a>,
  },
  {
    title: 'Age',
    dataIndex: 'age',
    key: 'age',
  },
  {
    title: 'Address',
    dataIndex: 'address',
    key: 'address',
  },
  {
    title: 'Tags',
    key: 'tags',
    dataIndex: 'tags',
    render: tags => (
      <span>
        {tags.map(tag => {
          let color = tag.length > 5 ? 'geekblue' : 'green'
          if (tag === 'loser') {
            color = 'volcano'
          }
          return (
            <Tag color={color} key={tag}>
              {tag.toUpperCase()}
            </Tag>
          )
        })}
      </span>
    ),
  },
  {
    title: 'Action',
    key: 'action',
    render: (text, record) => (
      <span>
        <a href="">Invite {record.name}</a>
        <Divider type="vertical" />
        <a href="">Delete</a>
      </span>
    ),
  },
]

class TablesAntdBasic extends React.Component {
  render() {
    return (
      <div className="mb-4 air__utils__scrollTable">
        <Table columns={columns} dataSource={data} scroll={{ x: '100%' }} />
      </div>
    )
  }
}

export default TablesAntdBasic
